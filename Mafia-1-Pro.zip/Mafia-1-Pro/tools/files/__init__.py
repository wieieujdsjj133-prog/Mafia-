"""Local file analysis helpers."""
