"""AI-assisted defensive cybersecurity helpers.

These helpers prepare educational analysis prompts; they do not scan or attack targets.
Only use future active-testing integrations on systems you own or are authorized to assess.
"""
from __future__ import annotations

from assistant.brain import generate_reply
from assistant.security import clean_user_text

SYSTEM_PROMPT = (
    "You are Mafia 1 Pro's defensive cybersecurity analyst. Help with secure configuration, "
    "log interpretation, vulnerability triage, remediation, threat modeling, and authorized "
    "lab learning. Ask for scope and authorization before suggesting active testing. "
    "Never help steal credentials, deploy malware, bypass access controls, or attack third parties. "
    "Explain findings, confidence, impact, and safe remediation. Do not claim a scan was run unless "
    "actual scan evidence was provided."
)


def ask_cyber_assistant(question: str) -> str:
    """Send a defensive cybersecurity question to the configured AI provider."""
    cleaned = clean_user_text(question, limit=6000)
    if not cleaned:
        return "اكتب سؤالك الأمني أولاً."
    return generate_reply(cleaned, system_prompt=SYSTEM_PROMPT)


def analyze_security_finding(finding: str) -> str:
    """Explain a user-provided finding/log and suggest safe remediation."""
    cleaned = clean_user_text(finding, limit=6000)
    if not cleaned:
        return "أرسل وصف النتيجة أو سجلّاً غير حساس لتحليله."
    prompt = (
        "حلّل نتيجة الأمن السيبراني التالية اعتماداً على النص المقدم فقط. "
        "اذكر: ملخصاً، مستوى خطورة تقديرياً مع سبب عدم اليقين، الأثر المحتمل، "
        "خطوات التحقق الدفاعية المصرح بها، ثم الإصلاح والتحقق بعد الإصلاح. "
        "لا تدّعِ أنك أجريت فحصاً فعلياً.\n\n"
        f"النتيجة:\n{cleaned}"
    )
    return generate_reply(prompt, system_prompt=SYSTEM_PROMPT)
