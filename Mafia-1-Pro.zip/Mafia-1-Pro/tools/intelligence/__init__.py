"""Open-source intelligence note-taking and public-source research helpers."""
