"""Web utilities namespace. Keep network features scoped and rate-limited."""
