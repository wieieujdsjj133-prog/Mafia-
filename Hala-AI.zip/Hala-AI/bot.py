import os
import sqlite3
import telebot
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
BOT_TOKEN = os.getenv('BOT_TOKEN', '').strip()
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '').strip()
MODEL = os.getenv('OPENAI_MODEL', 'gpt-4.1-mini').strip()
DB_PATH = os.getenv('DATABASE_PATH', 'hala_history.db')
if not BOT_TOKEN:
    raise RuntimeError('Missing BOT_TOKEN. Add it to your Codespaces secrets or .env file.')
if not OPENAI_API_KEY:
    raise RuntimeError('Missing OPENAI_API_KEY. Add it to your Codespaces secrets or .env file.')

bot = telebot.TeleBot(BOT_TOKEN)
ai = OpenAI(api_key=OPENAI_API_KEY)
SYSTEM_PROMPT = '''أنت جبتي المظلم، مساعد عربي ودود بشخصية غامضة ومرحة. تحدث مع المستخدم بصورة طبيعية دون مطالبته بصيغ أوامر. افهم قصده واسأل سؤالاً توضيحياً واحداً فقط عند الحاجة. يمكنك شرح البرمجة ومساعدة المستخدم على تطوير مشاريعه. في هذه النسخة لا تدّعِ أنك عدّلت ملفات فعلية أو شغّلت اختبارات ما لم يحدث ذلك عبر أدوات متصلة فعلاً. لا تطلب من المستخدم إرسال مفاتيح API أو كلمات المرور في المحادثة.'''

with sqlite3.connect(DB_PATH) as db:
    db.execute('CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)')

def save_message(user_id, role, content):
    with sqlite3.connect(DB_PATH) as db:
        db.execute('INSERT INTO messages(user_id, role, content) VALUES(?,?,?)', (user_id, role, content))

def get_history(user_id, limit=16):
    with sqlite3.connect(DB_PATH) as db:
        rows = db.execute('SELECT role, content FROM messages WHERE user_id=? ORDER BY id DESC LIMIT ?', (user_id, limit)).fetchall()
    return [{'role': role, 'content': content} for role, content in reversed(rows)]

def main_keyboard():
    kb = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row(telebot.types.KeyboardButton('😈 جبتي المظلم'))
    kb.row(telebot.types.KeyboardButton('🧹 مسح المحادثة'))
    return kb

@bot.message_handler(commands=['start', 'help'])
def start(message):
    bot.send_message(message.chat.id, '😈 أهلاً بك في جبتي المظلم... بماذا تفكّر؟\n\nاكتب لي بشكل طبيعي، كأنك تتحدث مع صديق. هذه النسخة الأولية تدعم المحادثة وحفظ سياقها.', reply_markup=main_keyboard())

@bot.message_handler(func=lambda m: m.text == '😈 جبتي المظلم')
def open_assistant(message):
    bot.send_message(message.chat.id, '😈👿💀🔥\nها أنا ذا... بماذا تفكّر؟ أخبرني بما يدور في رأسك.', reply_markup=main_keyboard())

@bot.message_handler(func=lambda m: m.text == '🧹 مسح المحادثة')
def reset(message):
    with sqlite3.connect(DB_PATH) as db:
        db.execute('DELETE FROM messages WHERE user_id=?', (message.from_user.id,))
    bot.send_message(message.chat.id, '🩸 تم مسح سياق محادثتنا. ابدأ من جديد: بماذا تفكّر؟', reply_markup=main_keyboard())

@bot.message_handler(content_types=['text'])
def chat(message):
    user_id = message.from_user.id
    text = (message.text or '').strip()
    if not text:
        return
    save_message(user_id, 'user', text)
    try:
        response = ai.responses.create(
            model=MODEL,
            instructions=SYSTEM_PROMPT,
            input=get_history(user_id),
            max_output_tokens=900,
        )
        answer = (response.output_text or '').strip() or '😈 لم أستطع صياغة رد هذه المرة. جرّب مرة أخرى.'
        save_message(user_id, 'assistant', answer)
        for i in range(0, len(answer), 3900):
            bot.send_message(message.chat.id, answer[i:i+3900], reply_markup=main_keyboard())
    except Exception as exc:
        # Avoid exposing secrets or raw provider errors to the user.
        print('AI request failed:', type(exc).__name__, str(exc)[:300])
        bot.send_message(message.chat.id, 'واجهت مشكلة في الاتصال بالعقل الذكي. تأكد من إعداد OPENAI_API_KEY واسم النموذج، ثم حاول مجدداً.', reply_markup=main_keyboard())

if __name__ == '__main__':
    print('Hala AI / جبتي المظلم is starting...')
    bot.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=30)
